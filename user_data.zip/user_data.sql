-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Июн 22 2021 г., 11:45
-- Версия сервера: 10.4.19-MariaDB
-- Версия PHP: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `user_data`
--

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(16) NOT NULL,
  `login` text NOT NULL,
  `password` text NOT NULL,
  `token` varchar(2048) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `password`, `token`) VALUES
(2, 'danek1', '1234', '-----BEGIN PRIVATE KEY-----\nMIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAJoEkP1H/hN4jfPG\naeS69ICTkfwLX4E8btuB+R6evJcVCZB8lDo8YIALuTMpP0EwgNlhSICZpdeI8Pai\n4Nu0sqeK6LI63oW2/H8eDGHqvxvfnsk+avEMPE6owLJ+owdrP6bUHf6uC9eiZ+k7\nNs826K+yG5uXB+ZpDCX9ajEGKGO7AgMBAAECgYACJxYvtBXlB8ZUJe3M+J/6PBXK\nRA5tq/6QqtxkhSt1oSGlF1irB7UBlShdgrIToy3p2+Y7heo/fPaBO/2QlJH6p/VQ\nOEikNYNVCcBiNI3hke0O/eNCGUZ272a7QaGoRWUlIQ5uk3JnH39+TXrps9+Ai4W1\nIsvhueIe6ETabZLQAQJBAMibbZOIGXG9FOT2AHy1Nb/yav/RER+kOvIUswfXDzGb\nx7vHBey3tEUteSyxWjBBVbSuoh82tHvqci3e+gx/5bsCQQDEi9IuXP4dIaLu6I8A\ndb3u3mrWAdfzJN/EvSRA4cvGGanwN8Xsp0NAjKjMOasGUSf0+IdNDWpyNHxdlaPa\nApoBAkAOM/LuHxSuGNUB4Ojn62yCyocI1aSAuP/zY8PJKlDJEl5xzQV+XQNGYpHR\nuDzKbdXDlRmlXBorK84psT/C4stBAkAT0s5mIrb2lTfrxMT3lOiNOR2pbBIt0eBH\n5ZPMf3mgB2KeeeGaltwvnIBB6OcZAgJ3sMFkwh+kWSrZ/YfDK1QBAkEAre/jye4D\nz0ojYwZIdT06EMnG6mKk8Vc+rX18f673aSAVxemLtFEWaq6HYYMzsQ6wbcgqJXa1\nE7JooMZX8QTxyQ==\n-----END PRIVATE KEY-----\n');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
